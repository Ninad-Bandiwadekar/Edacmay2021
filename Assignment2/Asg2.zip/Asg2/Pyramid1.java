class Pyramid1
{
	public static void main(String[]args)
	{
			int k=1;
		for(int i=1;i<=7;i++)
		{
			for(int j=1;j<=13;j++)
			{
				if(j>=8-i & j<=i+6 &k==1)
				{
					System.out.print(+i);
					k=0;
				}
				else
				{
					System.out.print(" ");
					k=1;
				}
			}
			System.out.println();
		}
	}
}