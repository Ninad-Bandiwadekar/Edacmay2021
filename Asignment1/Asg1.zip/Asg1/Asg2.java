class Asg2
{
	public static void main(String[]args)
	{
		int a=74;
		int b=36;
		System.out.println(+(a+b));
	}
	
}