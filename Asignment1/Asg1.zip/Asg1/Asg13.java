class Asg13
{
	public static void main(String[]args)
	{
		float w=5.6f;
		float h=8.5f;
		System.out.println("Area is"+w +"*" +h +"=" +(w*h));
		System.out.println("Perimeter is 2*("+w +"+"+h +") +"=" +(2*(w+h));
	}
}