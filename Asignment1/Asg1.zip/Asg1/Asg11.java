import java.util.*;

class Asg11
{
	public static void main(String []args)
	{
		Scanner s1=new Scanner(System.in);
		double r=s1.nextDouble();
		System.out.println("Perimeter is ="+2*3.14* +r);
		System.out.println("Area is ="+3.14* (+r)*+r);
	}
	
}