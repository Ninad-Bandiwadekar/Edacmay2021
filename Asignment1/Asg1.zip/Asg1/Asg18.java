
import java.util.*;


class Asg18
{
public static void main(String[]args)
{
	Scanner s1=new Scanner(System.in);
	int a=s1.nextInt();
	int b=s1.nextInt();
	int c=a*b;
	long binary=convertDecimaltoBinary(c);
	System.out.println("Multiplication of two binarynumber "+binary);
	
}
public static long convertDecimaltoBinary(int n)
{
	long binarynumber=0;
	int remainder, i=1;
	
	while(n!=0)
	{
		remainder=n%2;
		n=n/2;
		binarynumber=binarynumber+remainder*i;
		i=i*10;
	}
	return binarynumber;
}	
}