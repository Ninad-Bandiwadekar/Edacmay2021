import java.util.*;


class Asg19
{
public static void main(String[]args)
{
	Scanner s1=new Scanner(System.in);
	int a=s1.nextInt();
	
	long binary=convertDecimaltoBinary(a);
	System.out.println("Decimal to binary conversion "+binary);
	
}
public static long convertDecimaltoBinary(int n)
{
	long binarynumber=0;
	int remainder, i=1;
	int b[]=new int[10];
	
	while(n!=0)
	{
		remainder=n%2;
		n=n/2;
		binarynumber=binarynumber+remainder*i;
		i=i*10;
		b=remainder;
		System.out.print(b);
		
	}
	return binarynumber;
}	
}

/*
  Binarynumber    remainder   number    i
    0                           12       1
    0             0            6        10
	0             0            3         100
	100           1            1         1000
	1100           1            0        10000
	*/