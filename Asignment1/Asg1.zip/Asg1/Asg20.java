import java.util.*;




class Asg20
{
public static void main(String[]args)
{
	Scanner s1=new Scanner(System.in);
	int a=s1.nextInt();
	
	long binary=convertDecimaltoHexadecimal(a);
	
	
}
public static long convertDecimaltoHexadecimal(int n)
{
	long binarynumber=0;
	int remainder, i=1;
	
	while(n!=0)
	{
		remainder=n%16;
		n=n/16;
		if (remainder<10) //1 to 9 
		{
			System.out.print((char) (48+remainder));
		}
		else  //after 9 65-9=55
		{
			System.out.print((char) (55+remainder));
		}
	}
	return binarynumber;
}	
}