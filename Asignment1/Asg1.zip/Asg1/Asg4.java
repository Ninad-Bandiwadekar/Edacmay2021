import java.util.*;

class Asg4
{
	public static void main(String args[])
	{
		Scanner s1=new Scanner(System.in);
		int a=s1.nextInt();
		int b=s1.nextInt();
		//int c=s1.nextInt();
	   // System.out.println(-(+a)+(+b)*(+c));
	//	int d=s1.nextInt();
	//	int e=s1.nextInt();
	//	System.out.println(((+a)+(+b))%(+b));
		int f=s1.nextInt();
		int g=s1.nextInt();
		//System.out.println(((+f)+(-((+g)*(+a))))/(+b)); ?
		System.out.println(20+(-3)*5)/(8));
		
		
		
		
	}
	
}