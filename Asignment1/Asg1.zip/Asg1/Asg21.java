
import java.util.*;

class Asg21
{
	public static void main(String []args)
	{
		Scanner s1=new Scanner(System.in);
	    int n=s1.nextInt();
	  int remainder;
	  int a[]={0,1,2,3,4,5,6,7,8,9};
	  int []sum=new int[100];
	  int i=0;
	    while(n!=0)
	   {
		remainder=n%8;
		sum[i++]=(int)remainder;
	
          n=n/8;
	   }
	   for(int j=i-1;j>=0;j--)
	   {
		   System.out.print(sum[j]);
	   }
	    
	 
	
	}

}