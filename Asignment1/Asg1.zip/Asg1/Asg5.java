import java.util.*;
import java.lang.*;
import java.io.*;

class Asg5
{
public static void main(String[]args);
{
Scanner s1=new Scanner(System.in);
System.out.println("input first number");
int a=s1.nextInt();
System.out.println("input second number");
int b=s1.nextInt();
int c=a*b;
System.out.print(+a);
System.out.print(+b);
System.out.print(+c);


}



}