import java.util.*;

class Asg25
{
	public static void main(String[]args)
	{
		Scanner s1=new Scanner(System.in);
		long n=s1.nextLong();
		long base=1;
		long value=0;
		while(n!=0)
		{
			long remainder=n%10;
			value=value+remainder*base;
			base=base*8;
			n=n/10;
		}
		System.out.print("conversion from octal to decimal ="+value);
		
		
		
	}
}