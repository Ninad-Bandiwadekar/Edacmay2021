import java.util.*;


class Asg12
{
public static void main(String []args)
{
	Scanner s1=new Scanner(System.in);
	int a=s1.nextInt();
	int b=s1.nextInt();
	int c=s1.nextInt();
	int d=(a+b+c)/3;
	System.out.println("Avearage is" +d);
	
	
}
}