class Asg3
{
	public static void main(String args[])
	{
		int a=50/3;
		System.out.println(a);
	}
}