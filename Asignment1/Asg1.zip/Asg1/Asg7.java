import java.util.*;
import java.lang.*;
import java.io.*;

class Asg7
{
	public static void main(String[]args)
	{
		Scanner s1=new Scanner(System.in);
		int a=s1.nextInt();
		int i;
		for(i=1;i<=10;i++)
		{
		System.out.println(a + "*" + i + "=" +a*+i);
		}
	}
}