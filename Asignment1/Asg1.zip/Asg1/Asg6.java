import java.util.*;
import java.lang.*;
import java.io.*;

class Asg6
{
	public static void main(String args[])
	{
		Scanner s1=new Scanner(System.in);
		
		System.out.print("Input first number");
		int a=s1.nextInt();
		System.out.print("Input second number");
		int b=s1.nextInt();
		System.out.println(a +"+"+ b +"=" +(a+b));
		System.out.println(a+"-"+b +"="+(a-b));
		System.out.println(a+"X"+b +"="+(a*b));
	}
}