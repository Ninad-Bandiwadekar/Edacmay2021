import java.util.*;

class Asg22
{
	public static void main(String[]args)
	{
		Scanner s1=new Scanner(System.in);
		long n=s1.nextLong();
		long value=0;
		long base=1;
		long remainder;
		while(n!=0)
		{
			 remainder=n%10;
			value=value+remainder*base;
			base=base*2;
			n=n/10;
		}
	    System.out.print("Conversion from binary to decimal ="+value);
		
	}
	
	
	
}