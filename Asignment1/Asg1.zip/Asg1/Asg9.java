import java.util.*;


class Asg9
{
public static void main(String []args)
{
	Scanner s1=new Scanner(System.in);
	/*float a=s1.nextFloat();
	float b=s1.nextFloat();
	float c=s1.nextFloat();
	float d=s1.nextFloat();
	System.out.println((+a*(+b))-((+b)*(+b))/(((+c)-(+d))));*/
	System.out.println((25.5 * 3.5 - 3.5 * 3.5)/(40.5 - 4.5));
}

}

//(25.5 * 3.5 - 3.5 * 3.5) / (40.5 - 4.5))
