import java.util.*;


class Question2
{
	public static void main(String[]args)
	{
		Scanner s1=new Scanner(System.in);
		int a=s1.nextInt();
		for(int i=1;i<=10;i++)
			System.out.println(a+"*"+i+"="+(a*i));
	}
}