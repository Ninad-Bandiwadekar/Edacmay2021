class Question7
{

  public static void main(String[] args)
  {
    int a = 9;
    double b = a; 

    System.out.println(a);      
    System.out.println(b);  
	
	double c = 9.78;
    int d = (int) c;

    System.out.println(c);  
    System.out.println(d); 
	
	byte e=(byte)d;
	System.out.println(e); 
	
  }
}
