import java.util.*;

class Question4
{
	public static void main(String[]args)
	{
		Scanner s1=new Scanner(System.in);
		System.out.print("Enter a number");
		int a=s1.nextInt();
		if(a%2==0)
		{
			System.out.println(a+" Is a even number");
		}
		else
			System.out.println(a+" Is a odd number");
	}
}