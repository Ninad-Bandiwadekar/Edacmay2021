import java.util.*;

class Question6
{
	public static void main(String[]args)
	{
		

	   int max=0;
	   int max2=0;
		Scanner s1=new Scanner(System.in);
		int a[]=new int[5];
		System.out.print("Enter elements for array");
		for(int i=0;i<=4;i++)
		{
			a[i]=s1.nextInt();
		}
		for(int i=0;i<=4;i++)
		{
			
			if(a[i]>max)
			{
				max=a[i];	
	        }
		}
		System.out.println("max value is "+max);
		for(int i=0;i<=4;i++)
		{
			
			if(a[i]>max2 && a[i]!=max)
			{
				max2=a[i];	
	        }
		}
		System.out.println("Second max value is "+max2);
		
	}
}
	
